# SAE J2725 201603 BSM endoer/decoder

<!-- ABOUT THE PROJECT -->
## About the Project

Features:
- SAE J2735 source and header file compiled by ASN1C V0928
- SAE J2735 BSM encoder/decoder example written in C
- Python Bindings: Calling C from Python


<!-- GETTING STARTED -->
## Getting Started

### J2735 source and header file build by ASN1C V0928
ASN1C is open source and can be obtained from:
https://github.com/vlm/asn1c

### How to compile the encoder/decoder 
```bash
make
```

### How to run encoder/decoder 
```bash
./CID_MSG_Forwarder_2016
```

### To build Python wrapper:
```bash
python setup.py install
```
To test wrapper build successfully, or to check the usage of encoding and decoding functionalities:
```bash
python encode_example.py
python decode_example.py
```

<!-- CONTRIBUTING -->
## Contributing

Contributions are what make the open source community such an amazing place to be learn, inspire, and create. Any contributions you make are **greatly appreciated**.

1. Fork the Project
2. Create your Feature Branch (`git checkout -b feature/AmazingFeature`)
3. Commit your Changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the Branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

<!-- LICENSE -->
## License

Distributed under the MIT License. See `LICENSE` for more information.



<!-- CONTACT -->
## Contact

Henry Liu - henryliu@umich.edu

Developed by Rusheng Zhang and Sean Shen


<!-- MARKDOWN LINKS & IMAGES -->

[product-screenshot]: images/screenshot.png
