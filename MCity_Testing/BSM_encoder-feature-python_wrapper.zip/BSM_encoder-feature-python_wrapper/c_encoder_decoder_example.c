/*
* Generic converter template for a selected ASN.1 type.
* Copyright (c) 2005, 2006, 2007 Lev Walkin <vlm@lionet.info>.
* All rights reserved.
*
* To compile with your own ASN.1 type, please redefine the PDU as shown:
*
* cc -DPDU=MyCustomType -o myDecoder.o -c converter-sample.c
*/
#ifdef	HAVE_CONFIG_H
#include <config.h>
#endif
#include <stdio.h>

#include <sys/types.h>
#include <stdlib.h>	/* for atoi(3) */
#include <string.h>	/* for strerror(3) */
#include <errno.h>	/* for errno */
#include "asn_application.h"
#include "asn_internal.h"	/* for _ASN_DEFAULT_STACK_MAX */
#include "BasicSafetyMessage.h"

int ret;
asn_enc_rval_t ec; /* Encoder return value */
asn_dec_rval_t rval;

#define BUFFER_SIZE 200

static uint8_t buf[BUFFER_SIZE];
size_t size = 100;

char TemporaryID[4] = {'1', '0', '2', '4'};
long transmission_int = 1;
long traction_int = 1;
long aabbs_int = 2;
long ssccss_int = 3;
long brakeBoost_int = 2;
long auxBrakes_int = 3;
uint8_t wheelBrakes=3;
unsigned char szData[100];

int main(int ac, char *av[]) {
	int i;

	BasicSafetyMessage_t * BSMType = 0;
	BasicSafetyMessage_t * BSMType_decode = 0;
	BSMcoreData_t * coreData = 0;

	BSMType = (BasicSafetyMessage_t *)calloc(1, sizeof(BasicSafetyMessage_t));
	BSMType_decode = (BasicSafetyMessage_t *)calloc(1, sizeof(BasicSafetyMessage_t));


	BSMType->coreData.msgCnt=100; //(0..127)

    BSMType->coreData.id=*OCTET_STRING_new_fromBuf(&asn_DEF_OCTET_STRING, (char*)&TemporaryID, 4);

	BSMType->coreData.secMark = 666; // (0..60999) A leap second is represented by the value range 60000 to 60999, unit: milliseconds within a minute

	BSMType->coreData.lat = 422808000; //INTEGER (-900000000..900000001)

	BSMType->coreData.Long = -832808000; //INTEGER (-900000000..900000001)

	BSMType->coreData.elev = 10; //INTEGER (-4096..61439) unit: cm

	BSMType->coreData.accuracy.semiMajor = 15;
	BSMType->coreData.accuracy.semiMinor = 5;
	BSMType->coreData.accuracy.orientation = 20;

	///transmissionstate///
	BSMType->coreData.transmission = transmission_int;

	BSMType->coreData.speed = 40; //INTEGER (0..8191) -- Units of 0.02 m/s
	BSMType->coreData.heading = 14400; //INTEGER (0..28800) -- LSB of 0.0125 degrees -- A range of 0 to 359.9875 degrees
	BSMType->coreData.angle = 5;

	///acceleration///
	BSMType->coreData.accelSet.Long = 5;
	BSMType->coreData.accelSet.lat = 12;
	BSMType->coreData.accelSet.vert = 15;
	BSMType->coreData.accelSet.yaw = 200;

	///brakesystemstatus//
	BSMType->coreData.brakes.wheelBrakes.buf = calloc(1, 1);
	assert(BSMType->coreData.brakes.wheelBrakes.buf);
	BSMType->coreData.brakes.wheelBrakes.size = 1;
	BSMType->coreData.brakes.wheelBrakes.buf[0] |= 1 << (7 - BrakeAppliedStatus_leftFront);
	BSMType->coreData.brakes.wheelBrakes.bits_unused = 3;

	BSMType->coreData.brakes.traction = traction_int;
	BSMType->coreData.brakes.abs = aabbs_int;
	BSMType->coreData.brakes.scs = ssccss_int;
	BSMType->coreData.brakes.brakeBoost = brakeBoost_int;
	BSMType->coreData.brakes.auxBrakes = auxBrakes_int;

	///vehicle size///
	BSMType->coreData.size.length = 500;//INTEGER (0..1023) -- LSB units are 1 cm with a range
	BSMType->coreData.size.width = 250;//INTEGER (0..1023) -- LSB units are 1 cm with a range

	printf("Call Encoder...\n");
	ec = uper_encode_to_buffer(&asn_DEF_BasicSafetyMessage, 0,BSMType, buf, BUFFER_SIZE);


	printf("Encode code: %d!\n",ec.encoded);

	if (ec.encoded == -1)
	{
		printf("%s: %s\n", ec.failed_type->name, strerror(errno));
	}


	printf("Buffer after encoding:\n");
	for (i = 0; i<200; i++)
		printf("%x\t", (uint8_t)buf[i]);

    //unsigned char buf2[200] = {0x00,0x00,0x05, 0x07, 0x5A,0x80,0x00,0x03,0x00,0x10,0x45,0x44,0x48,0x94,0x48,0x90,0x01,0x02,0x1A,0x22,0x4E,0xA2,0x4E,0x80,0x0C,0x11,0x51,0x12,0x25,0x12,0x24,0x00,0x80,0x86,0x88,0x93,0xA8,0x93,0xA0 };

   // unsigned char buf2[10000] = {0x5A, 0x1B,0x1F,0xC8,0x7C,0x86,0x58,0xE7,0x6B,0xF5,0x77,0x1C,0xB3,0x33,0xE3,0x0B,0xC9,0x82,0x82,0x3F,0xF2,0x70,0x00,0x6F,0xFF,0xFD, 0x7D, 0x0F, 0xA1, 0xB1, 0x7F, 0xFF, 0x80, 0x00, 0x5C, 0x0E, 0x88,0x00,0x9C,0xC0,0x61,0x06,0x55,0x3F,0xEF,0xEF,0xF6,0x00, 0x00,0x12,0x18,0x83,0xF7,0xF6,0xFB,0x40,0x00,0x01,0x44,0x6B,0x3E,0xB7,0xEF,0x70,0x00,0x00,0x14,0xE4, 0xA3,0xE5,0x5C,0xF7,0xE0,0x00,0x0F,0xFF, 0xEC,0x80};


	if (rval.code == RC_OK)
	{

        printf("\n");
        printf("Call Decoder...:\n");
		printf("Decode successfully!!!!!!!!!!!!!!!\n");
        rval = uper_decode(0, &asn_DEF_BasicSafetyMessage, (void **)&BSMType_decode, buf, size,0,0);
        printf("BSM Decoded! BsmMsgCount: %d\n", BSMType_decode->coreData.msgCnt);
        xer_fprint(stdout, &asn_DEF_BasicSafetyMessage, BSMType_decode);

        OCTET_STRING_t id;
		id = BSMType_decode->coreData.id;

		char idDecodeTemp[4];
		uint8_t *bufTemp;
		bufTemp = id.buf;

		memcpy(idDecodeTemp, bufTemp, 4);


		printf("idDecoded: %c, %c, %c, %c\n", idDecodeTemp[0], idDecodeTemp[1], idDecodeTemp[2], idDecodeTemp[3]);

		//TemporaryID = idDecodeTemp[0] + 256 * idDecodeTemp[1] + 256 * 256 * idDecodeTemp[2] + 256 * 256 * 256 * idDecodeTemp[3];
		int secMarkDecoded = BSMType_decode->coreData.secMark;
		printf("secMarkDecoded: %i\n", secMarkDecoded);

		int msgCountDecoded = BSMType_decode->coreData.msgCnt;
		printf("msgCountDecoded: %i\n", msgCountDecoded);

		int speedDecoded = BSMType_decode->coreData.speed;
		printf("speedDecoded: %i\n", speedDecoded);

		int headingDecoded = BSMType_decode->coreData.heading;
		printf("headingDecoded: %i\n", headingDecoded);

		int latDecoded = BSMType_decode->coreData.lat;
		printf("latDecoded: %i\n", latDecoded);

		int LongDecoded = BSMType_decode->coreData.Long;
		printf("LongDecoded: %i\n", LongDecoded);

		int elevDecoded = BSMType_decode->coreData.elev;
		printf("elevDecoded: %i\n", elevDecoded);

		int vehlengthDecoded = BSMType_decode->coreData.size.length;
		printf("vehlengthDecoded: %i\n", vehlengthDecoded);

		int vehwidthDecoded = BSMType_decode->coreData.size.width;

		printf("vehwidthDecoded: %i\n", vehwidthDecoded);

	}

	//printf("msgID=%d Timetochange=%d", BSMType_decode->msgID, BSMType_decode->intersections.list.array[0]->states.list.array[1]->timeToChange);
	return 0;
}

