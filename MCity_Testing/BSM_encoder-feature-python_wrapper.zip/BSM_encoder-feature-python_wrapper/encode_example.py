import BSMEncoder
def encode_example():
    temporaryID = '1024'
    ## position:
    lon = -832808000
    lat = 422808000
    elev = 10 
    ## accuracy:
    semiMajor = 15 
    semiMinor = 10 
    orientation = 20
    speed = 40 # INTEGER (0..8191) -- Units of 0.02 m/s
    heading = 14400 #INTEGER (0..28800) -- LSB of 0.0125 degrees -- A range of 0 to 359.9875 degrees 
    angle = 5
    ## accelerations:
    acc_long = 5
    acc_lat = 12
    acc_vert = 15 
    acc_yaw = 200
    ## size
    length = 500 #INTEGER (0..1023) -- LSB units are 1 cm with a range
    width = 250 #INTEGER (0..1023) -- LSB units are 1 cm with a range
    ## control
    secMark = 666
    msgCnt = 10
    x = BSMEncoder.encode(temporaryID, lon, lat, elev, semiMajor, semiMinor, orientation, speed, heading, angle, acc_long, acc_lat, acc_vert, acc_yaw, length, width, msgCnt, secMark)
    print(x)
    return x

if __name__ == '__main__':
    encode_example()