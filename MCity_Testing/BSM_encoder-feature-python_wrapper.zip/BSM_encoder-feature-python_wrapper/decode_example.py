from encode_example import encode_example
import BSMEncoder
def decode_example():
    encoded = encode_example()
    (id, secMark, msgCount, speed, heading, lat, lon, elev, length, width) = BSMEncoder.decode(encoded)
    print(f'id: {id}\nsecMark: {secMark}\nmsgCount: {msgCount}\nspeed: {speed}\nheading: {heading}\nlat: {lat}\nlon: {lon}\nelev: {elev}\nlength: {length}\nwidth: {width}')

if __name__ == '__main__':
    decode_example()