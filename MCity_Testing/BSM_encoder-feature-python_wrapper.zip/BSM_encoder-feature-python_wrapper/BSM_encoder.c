#include <Python.h>
#ifdef	HAVE_CONFIG_H
#include <config.h>
#endif
#include <stdio.h>

#include <sys/types.h>
#include <stdlib.h>	/* for atoi(3) */
#include <string.h>	/* for strerror(3) */
#include <errno.h>	/* for errno */
#include "asn_application.h"
#include "asn_internal.h"	/* for _ASN_DEFAULT_STACK_MAX */
#include "BasicSafetyMessage.h"
#define BUFFER_SIZE 200
 
static PyObject* encode(PyObject* self, PyObject* args)
{
    char* temporaryID;
    int lon, lat, elev, semiMajor, semiMinor, orientation, speed, heading, angle, acc_long, acc_lat, acc_vert, acc_yaw, length, width, msgCnt, secMark;
    if (!PyArg_ParseTuple(args, "siiiiiiiiiiiiiiiii", &temporaryID, &lon, &lat, &elev, &semiMajor, &semiMinor, &orientation, &speed, &heading, &angle, &acc_long, &acc_lat, &acc_vert, &acc_yaw, &length, &width, &msgCnt, &secMark)) {
        printf("encoder input is NOT correct, please check");
        return NULL;
    }
    asn_enc_rval_t ec; /* Encoder return value */
    static char buf[BUFFER_SIZE];
    long transmission_int = 1;
    long traction_int = 1;
    long aabbs_int = 2;
    long ssccss_int = 3;
    long brakeBoost_int = 2;
    long auxBrakes_int = 3;
    BasicSafetyMessage_t * BSMType = 0;
	BSMType = (BasicSafetyMessage_t *)calloc(1, sizeof(BasicSafetyMessage_t));
	BSMType->coreData.msgCnt= msgCnt; //(0..127)
    BSMType->coreData.id=*OCTET_STRING_new_fromBuf(&asn_DEF_OCTET_STRING, temporaryID, 4);
    BSMType->coreData.secMark = secMark; // (0..60999) A leap second is represented by the value range 60000 to 60999, unit: milliseconds within a minute
    BSMType->coreData.lat = lat;
    BSMType->coreData.Long = lon;
    BSMType->coreData.elev = elev;
    BSMType->coreData.accuracy.semiMajor = semiMajor;
    BSMType->coreData.accuracy.semiMinor = semiMinor;
    BSMType->coreData.accuracy.orientation = orientation;
    BSMType->coreData.transmission = transmission_int;
    BSMType->coreData.speed = speed;
    BSMType->coreData.heading = heading;
    BSMType->coreData.angle = angle;
    BSMType->coreData.accelSet.Long = acc_long;
	BSMType->coreData.accelSet.lat = acc_lat;
	BSMType->coreData.accelSet.vert = acc_vert;
	BSMType->coreData.accelSet.yaw = acc_yaw;
    //brakesystemstatus//
	BSMType->coreData.brakes.wheelBrakes.buf = calloc(1, 1);
	assert(BSMType->coreData.brakes.wheelBrakes.buf);
	BSMType->coreData.brakes.wheelBrakes.size = 1;
	BSMType->coreData.brakes.wheelBrakes.buf[0] |= 1 << (7 - BrakeAppliedStatus_leftFront);
	BSMType->coreData.brakes.wheelBrakes.bits_unused = 3;

	BSMType->coreData.brakes.traction = traction_int;
	BSMType->coreData.brakes.abs = aabbs_int;
	BSMType->coreData.brakes.scs = ssccss_int;
	BSMType->coreData.brakes.brakeBoost = brakeBoost_int;
	BSMType->coreData.brakes.auxBrakes = auxBrakes_int;
    ///vehicle size///
	BSMType->coreData.size.length = length;//INTEGER (0..1023) -- LSB units are 1 cm with a range
	BSMType->coreData.size.width = width;//INTEGER (0..1023) -- LSB units are 1 cm with a range

    // printf("-----start encoding-----------\n");
    // printf("temporary ID: %s\n", temporaryID);
    // printf("longitude: %i\n", lon);
    // printf("lattitude: %i\n", lat);
    // printf("elevation: %i\n", elev);
    // printf("accuracy-semimajor: %i\n", semiMajor);
    // printf("accuracy-semiminor: %i\n", semiMinor);
    // printf("accuracy-orientation: %i\n", orientation);
    // printf("speed: %i\n", speed);
    // printf("heading: %i\n", heading);
    // printf("angle: %i\n", angle);
    // printf("acceleration long: %i\n", acc_long);
    // printf("acceleration lat: %i\n", acc_lat);
    // printf("acceleration vert: %i\n", acc_vert);
    // printf("acceleration yaw: %i\n", acc_yaw);
    // printf("length: %i \n", length);
    // printf("width: %i\n", width);
    ec = uper_encode_to_buffer(&asn_DEF_BasicSafetyMessage, 0,BSMType, buf, BUFFER_SIZE);
    if (ec.encoded == -1)
	{
		printf("%s: %s\n", ec.failed_type->name, strerror(errno));
        return NULL;
	}
    // printf("Buffer after encoding:\n");
	// for (int i = 0; i<200; i++)
	// 	printf("%x\t", (uint8_t)buf[i]);
    return Py_BuildValue("O", PyByteArray_FromStringAndSize(buf, (Py_ssize_t)BUFFER_SIZE));
}

static PyObject* decode(PyObject* self, PyObject* args)
{
    asn_dec_rval_t rval;
    BasicSafetyMessage_t * BSMType_decode = 0;
    char idDecodeTemp[4];
    int secMarkDecoded, msgCountDecoded, speedDecoded, headingDecoded, latDecoded, longDecoded, elevDecoded, vehlengthDecoded, vehwidthDecoded;
    PyByteArrayObject* encoded;
    if (!PyArg_ParseTuple(args, "Y", &encoded)) {
        printf("encoder input is NOT correct, please check");
        return NULL;
    }
    static char* buf;
    buf = PyByteArray_AsString(encoded);
    rval = uper_decode(0, &asn_DEF_BasicSafetyMessage, (void **)&BSMType_decode, buf, BUFFER_SIZE,0,0);
    if (rval.code == RC_OK)
	{
		// printf("Decode successfully!!!!!!!!!!!!!!!\n");
        // printf("BSM Decoded! BsmMsgCount: %d\n", BSMType_decode->coreData.msgCnt);
        OCTET_STRING_t id;
		id = BSMType_decode->coreData.id;
		uint8_t *bufTemp;
		bufTemp = id.buf;
		memcpy(idDecodeTemp, bufTemp, 4);
		// printf("idDecoded: %c, %c, %c, %c\n", idDecodeTemp[0], idDecodeTemp[1], idDecodeTemp[2], idDecodeTemp[3]);
		//TemporaryID = idDecodeTemp[0] + 256 * idDecodeTemp[1] + 256 * 256 * idDecodeTemp[2] + 256 * 256 * 256 * idDecodeTemp[3];
		secMarkDecoded = BSMType_decode->coreData.secMark;
		// printf("secMarkDecoded: %i\n", secMarkDecoded);
		msgCountDecoded = BSMType_decode->coreData.msgCnt;
		// printf("msgCountDecoded: %i\n", msgCountDecoded);
		speedDecoded = BSMType_decode->coreData.speed;
		// printf("speedDecoded: %i\n", speedDecoded);
		headingDecoded = BSMType_decode->coreData.heading;
		// printf("headingDecoded: %i\n", headingDecoded);
		latDecoded = BSMType_decode->coreData.lat;
		// printf("latDecoded: %i\n", latDecoded);
		longDecoded = BSMType_decode->coreData.Long;
		// printf("LongDecoded: %i\n", longDecoded);
		elevDecoded = BSMType_decode->coreData.elev;
		// printf("elevDecoded: %i\n", elevDecoded);
		vehlengthDecoded = BSMType_decode->coreData.size.length;
		// printf("vehlengthDecoded: %i\n", vehlengthDecoded);
		vehwidthDecoded = BSMType_decode->coreData.size.width;
		// printf("vehwidthDecoded: %i\n", vehwidthDecoded);

	}
    return Py_BuildValue("Oiiiiiiiii", PyByteArray_FromStringAndSize(idDecodeTemp, (Py_ssize_t)4), secMarkDecoded, msgCountDecoded, speedDecoded, headingDecoded, latDecoded, longDecoded, elevDecoded, vehlengthDecoded, vehwidthDecoded);
}

static PyObject* version(PyObject* self)
{
    return Py_BuildValue("s", "Version 1.0");
}
 
static PyMethodDef myMethods[] = {
    {"encode", encode, METH_VARARGS, "encode BSM message"},
    {"decode", decode, METH_VARARGS, "decode BSM message"},
    {"version", (PyCFunction)version, METH_NOARGS, "Returns the version."},
    {NULL, NULL, 0, NULL}
};
 
static struct PyModuleDef BSMEncoder = {
	PyModuleDef_HEAD_INIT,
	"BSMEncoder", //name of module.
	"BSM Encoder and decoder",
	-1,
	myMethods
};

PyMODINIT_FUNC PyInit_BSMEncoder(void)
{
    return PyModule_Create(&BSMEncoder);
}
