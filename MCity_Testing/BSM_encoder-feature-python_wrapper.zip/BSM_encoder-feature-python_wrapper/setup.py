from distutils.core import setup, Extension
import os, glob
sources = glob.glob('utils/*.c')
sources.append('BSM_encoder.c')
module = Extension("BSMEncoder",
    sources = sources,
    include_dirs = ['utils/', '/usr/include'],
    extra_compile_args=['-Wall', '-DPRINT_LOG', '-std=c++0x', '-O3'],
    library_dirs = [os.path.join(os.getcwd(), 'utils')])

setup(name="PackageName",
      version = "1.0", 
      description = "This is a package for my C module",
      ext_modules = [module])